package com.cognizant.usecase5.carservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.usecase5.carservice.entity.Address;

public interface AddressDao extends JpaRepository<Address, Long> {

}
