package com.cognizant.usecase5.carservice.entity;

import java.sql.Timestamp;
import java.time.LocalDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class Car {

	@Id
	@GeneratedValue
	private long id;

	@NotEmpty(message="CarMaker name can't be empty")
	@Size(min=4, max=10, message="Car maker name should be not less than 4 and greater than 10")
	private String carMaker;

	@NotEmpty(message="Model name can't be null")
	@Size(min=4, max=10, message="model name should be not less than 4 and greater than 10")
	private String modelName;

	@NotEmpty(message="Registration number can't be null")
	@Size(min=8, max=8, message="Registration number should be of length 8")
	private String regNumber;

	//@NotEmpty(message="Chasis number can't be empty")
	@Min(value=100000,message="Chasis number should not be less than 100000")
	@Max(value=999999,message="Chasis number should not be greater than 2000000")
	private Long chasisNumber;

	//@NotEmpty(message=" name can't be null")
	@Size(min=4, max=20, message="Known issues should be not less than 4 and greater than 20")
	private String knownIssues;

	//@NotEmpty(message="Cost can't be empty")
	@Min(value=100000,message="Cost should not be less than 100000")
	@Max(value=2000000,message="Cost should not be greater than 2000000")
	private Long cost;

	private Timestamp givenDate;
	private LocalDate expectedDeliveryDate;
	private Timestamp createdDateNTime;
	private Timestamp updatedDateNTime;

	@OneToOne(cascade = CascadeType.ALL)
	private Address address;

//	@NotNull()
	@Min(value=1,message="Phone number should be of 9 digits")
	@Max(value=999999999,message="Phone number should be of 9 digits")
	private Long phoneNumber;

	// no arg constructor
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}

	// Parameterized Constructor
	public Car(long id, String carMaker, String modelName, String regNumber, Long chasisNumber, String knownIssues,
			Long cost, Timestamp givenDate, LocalDate expectedDeliveryDate, Timestamp createdDateNTime,
			Timestamp updatedDateNTime, Address address, Long phoneNumber) {
		super();
		this.id = id;
		this.carMaker = carMaker;
		this.modelName = modelName;
		this.regNumber = regNumber;
		this.chasisNumber = chasisNumber;
		this.knownIssues = knownIssues;
		this.cost = cost;
		this.givenDate = givenDate;
		this.expectedDeliveryDate = expectedDeliveryDate;
		this.createdDateNTime = createdDateNTime;
		this.updatedDateNTime = updatedDateNTime;
		this.address = address;
		this.phoneNumber = phoneNumber;
	}

	// getters-setters method

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCarMaker() {
		return carMaker;
	}

	public void setCarMaker(String carMaker) {
		this.carMaker = carMaker;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getRegNumber() {
		return regNumber;
	}

	public void setRegNumber(String regNumber) {
		this.regNumber = regNumber;
	}

	public Long getChasisNumber() {
		return chasisNumber;
	}

	public void setChasisNumber(Long chasisNumber) {
		this.chasisNumber = chasisNumber;
	}

	public String getKnownIssues() {
		return knownIssues;
	}

	public void setKnownIssues(String knownIssues) {
		this.knownIssues = knownIssues;
	}

	public Long getCost() {
		return cost;
	}

	public void setCost(Long cost) {
		this.cost = cost;
	}

	public Timestamp getGivenDate() {
		return givenDate;
	}

	public void setGivenDate(Timestamp givenDate) {
		this.givenDate = givenDate;
	}

	public LocalDate getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}

	public void setExpectedDeliveryDate(LocalDate expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	public Timestamp getCreatedDateNTime() {
		return createdDateNTime;
	}

	public void setCreatedDateNTime(Timestamp createdDateNTime) {
		this.createdDateNTime = createdDateNTime;
	}

	public Timestamp getUpdatedDateNTime() {
		return updatedDateNTime;
	}

	public void setUpdatedDateNTime(Timestamp updatedDateNTime) {
		this.updatedDateNTime = updatedDateNTime;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	// toString Method
	@Override
	public String toString() {
		return "Car [id=" + id + ", carMaker=" + carMaker + ", modelName=" + modelName + ", regNumber=" + regNumber
				+ ", chasisNumber=" + chasisNumber + ", knownIssues=" + knownIssues + ", cost=" + cost + ", givenDate="
				+ givenDate + ", expectedDeliveryDate=" + expectedDeliveryDate + ", createdDateNTime="
				+ createdDateNTime + ", updatedDateNTime=" + updatedDateNTime + ", address=" + address
				+ ", phoneNumber=" + phoneNumber + "]";
	}

}
