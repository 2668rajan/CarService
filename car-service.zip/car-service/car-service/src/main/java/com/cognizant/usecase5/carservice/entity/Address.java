package com.cognizant.usecase5.carservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

@Entity
public class Address {

	@Id
	@GeneratedValue
	private int houseNo;

	@NotEmpty(message="Street name can't be empty")
	@Size(min=4, max=10, message="Street name should be not less than 4 and greater than 10")
	private String street;

//	@NotEmpty(message="Landmark can't be null")
//	@Size(min=4, max=10, message="Landmark should be not less than 4 and greater than 10")
	private String landmark;

//	@NotEmpty(message="City name can't be null")
//	@Size(min=4, max=10, message="City name should be not less than 4 and greater than 10")
	private String city;

//	@NotEmpty(message="State name can't be null")
//	@Size(min=4, max=10, message="State name should be not less than 4 and greater than 10")
	private String state;

//	@NotEmpty(message="Pin code can't be empty")
//	@Min(value=100000,message="Pin code should not be less than 100000")
//	@Max(value=999999,message="Pin code should not be greater than 2000000")
	private Long pin;

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int houseNo, String street, String landmark, String city, String state, Long pin) {
		super();
		this.houseNo = houseNo;
		this.street = street;
		this.landmark = landmark;
		this.city = city;
		this.state = state;
		this.pin = pin;
	}

	public int getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getPin() {
		return pin;
	}

	public void setPin(Long pin) {
		this.pin = pin;
	}

	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", street=" + street + ", landmark=" + landmark + ", city=" + city
				+ ", state=" + state + ", pin=" + pin + "]";
	}

}
