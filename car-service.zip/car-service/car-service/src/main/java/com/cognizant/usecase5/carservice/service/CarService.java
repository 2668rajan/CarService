package com.cognizant.usecase5.carservice.service;

import java.util.List;

import com.cognizant.usecase5.carservice.entity.Car;
import com.cognizant.usecase5.carservice.exception.CarNotFoundException;

public interface CarService {

	List<Car> getAllCars();

	Car getCar(Long parseLong);

	Car addCar(Car car);

	Car updateCar(Long id, Car car) throws CarNotFoundException;

	void deleteCar(long parseLong);

	boolean carExist(long l);

	boolean carExistByChasisNumber(Long chasisNUmber);

	boolean carExistByRegNumber(String regNumber);

}
