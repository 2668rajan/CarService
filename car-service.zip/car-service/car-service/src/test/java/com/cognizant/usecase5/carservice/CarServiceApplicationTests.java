package com.cognizant.usecase5.carservice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.usecase5.carservice.dao.CarDao;
import com.cognizant.usecase5.carservice.entity.Address;
import com.cognizant.usecase5.carservice.entity.Car;
import com.cognizant.usecase5.carservice.service.CarService;

@SpringBootTest
class CarServiceApplicationTests {

	@Autowired
	private CarDao carDao;

	@Autowired
	private CarService carService;

	@Test
	void contextLoads() {
	}

	@BeforeEach
	// @Disabled
	void setUp() {
		System.out.println("Setting Up");

		Address address = new Address(1, "Narone", "near bsnl Tower", "Hisar", "Madhubani", 847230l);

		Car car = new Car(1, "Toyota", "Corolla", "ABCD1223", 112233L, "Break Fail", 200000L,
				new Timestamp(System.currentTimeMillis()), LocalDate.of(2023, 4, 1),
				new Timestamp(System.currentTimeMillis()), new Timestamp(System.currentTimeMillis()), address,
				877929825L);

		carDao.save(car);
	}

	@Test
	// @Disabled
	void gatAllCars() {
		List<Car> actual = carDao.findAll();
		assertThat(actual).asList();
	}

	@Test
	void getCar() {
		Optional<Car> actual = carDao.findById(1l);
		assertThat(actual).isNotEmpty();
	}

	@Test
	void addCar() {
		Address address = new Address(1, "Narone", "near bsnl Tower", "Hisar", "Madhubani", 847230l);

		Car car1 = new Car(2, "Toyota", "Corolla", "ABAD1223", 212233L, "Break Fail", 200000L,
				new Timestamp(System.currentTimeMillis()), LocalDate.of(2023, 4, 1),
				new Timestamp(System.currentTimeMillis()), new Timestamp(System.currentTimeMillis()), address,
				877929825L);
		
		carDao.save(car1);
	}
	
	@Test
	void updateCar() {
		Address address = new Address(1, "Narone", "near bsnl Tower", "Hisar", "Madhubani", 847230l);

		Car car2 = new Car(2, "Toyota", "Corolla", "SBAD1223", 232233L, "Break Fail", 200000L,
				new Timestamp(System.currentTimeMillis()), LocalDate.of(2023, 4, 1),
				new Timestamp(System.currentTimeMillis()), new Timestamp(System.currentTimeMillis()), address,
				877929825L);

		carDao.save(car2);
		
		
	}
	
	@Test
	void deleteCar() {
		carDao.deleteById(1l);
		
	}
	
	@Test
	void carExist(){
		boolean actual = carDao.existsById(1l);
		
		assertThat(actual).isTrue();
	}
	
	@Test
	void carExistByChasisNumber() {
		 
		boolean actual = carDao.existsByChasisNumber(212233L);
		assertThat(actual).isTrue();
	}

	@Test
	void carExistByRegNumber() {
		boolean actual = carDao.existsByRegNumber("ABAD1223");
		assertThat(actual).isTrue();
	}
	
	@AfterEach
	void tearDown() {
		System.out.println("tearing down");
	}
}
